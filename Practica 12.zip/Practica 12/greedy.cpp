#include <vector>
#include <list>
#include <iostream>

int main() {
float valor;
std::cin >> valor;
int valor_cent =(int) (valor * 100);
std::vector<int> conjunto_posibles = {200, 100, 50, 20, 10, 5, 2, 1};
int aux = valor_cent;
int  i = 0, k = 0;

std::vector<std::vector<int> > solucion;
solucion.resize(8);
std::cout<<"S: {";
do {
  if( conjunto_posibles[i] <= aux) {
    aux = aux - conjunto_posibles[i];
    solucion[k].push_back(conjunto_posibles[i]);
  }
  if (conjunto_posibles[i] > aux) {
    if( !(solucion[k].size() == 0)) {
    std::string moneda="euros";
    int divisor=100;
    if( solucion[k][0] < 100){
      moneda="centimos";
      divisor = 1;
    }

      std::cout << solucion[k].size() << " x " << solucion[k][0]/divisor<< " "<<moneda<<" ";
    k++;
    }
    i++;
  }
}
while( aux > 0);
std::cout<<"}"<<'\n';
return 0;
}
