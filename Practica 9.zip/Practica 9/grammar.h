// Universidad de La Laguna
// Escuela Superior de Ingenier�a y Tecnolog�a
// Grado en Ingenier�a Inform�tica
// Asignatura: Computabilidad y Algoritmia (CyA)
// Curso: 2 
// Pr�ctica 9 CyA -  Gramaticas Regulares y Automatas Finitos
// Autor: Jose Yuyari Milian Martinelli
// Correo: alu0101129730@ull.edu.es
// Fecha: 11/11/2019
// Archivo grammar.h: Contiene la declaracion de la clase Grammar
// Referencias: 
//                    Enunciado de la pr�ctica:
//                    https://campusvirtual.ull.es/1920/pluginfile.php/147981/mod_assign/introattachment/0/CYA_1920_Practica_8.pdf?forcedownload=1

#include <set>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <iostream>
#include <stdio.h>
class Grammar{
  //Clase que especifica una gramatica regular
  //Atributos de una gramatica
  std::set<char> alphabet;			    /**< un set que contiene los simbolos del alfabeto de la gramatica */
  std::set<std::string> non_terminal;		    /**< un set que contiene los simbolos No terminales de la gramatica */
  std::string start;				    /**< un string que es el No terminal de inicio */
  std::set< std::vector<std::string> > productions; /**< set que contiene vectores de dos strings, simbolizando cada produccion */
  public:
  /**
   * @brief Un constructor con un argumento
   * @param fichero el nombre del archivo que contiene la informacion de la gramatica
   */
  Grammar( std::string fichero){
    SetGrammar( fichero);
  }
  /**
   * Un constructor por defecto
   */
  Grammar(){}
  /**
   * @brief Funcion que lee el fichero de especificacion y asigna los valores de los atributos
   * @param fichero el nombre del archivo que contiene la informacion de la gramatica
   */
  void SetGrammar( std::string fichero);
  /**
   * @brief Funcion que imprime las caracteristicas de la Gramatica en un fichero
   */
  void ImprimirGrammar( std::string salida_fichero);
  /**
   * @brief Funcion que transforma la gramatica CFG (Context-Free Grammar) a CNF
   * ( Chomsky Normal Form)
   */
  void ChomskyForm();
  /**
   * @brief Funcion que crea un objeto NFA que representa al mismo lenguaje que la Gramatica
   * @return Objeto NFA
   */
//  NFA CreateNFA();
  /**
   * @brief Funcion que crea los estados y transiciones necesarios para el NFA
   * @param states vector que se pasa por referencia y que contiene los No terminales de la gramatica y un nuevo estado final F
   * @param transitions vector de vectores que se pasa por referencia y esta vacio
   */
  void SetNFAStatesTransitions( std::vector<std::string> &states, std::vector<std::vector<std::string> > &transitions); 
};
