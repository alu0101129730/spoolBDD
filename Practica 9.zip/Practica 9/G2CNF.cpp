// Universidad de La Laguna
// Escuela Superior de Ingenieria y Tecnologia
// Grado en Ingenieria Informatica
// Asignatura: Computabilidad y Algoritmia (CyA)
// Curso: 2 
// Practica 9 CyA -  Gramaticas Regulares y Automatas Finitos
// Autor: Jose Yuyari Milian Martinelli
// Correo: alu0101129730@ull.es
// Fecha: 17/11/2019
// Archivo G2CNF.cpp: programa cliente. Contiene la funcion main del proyecto
//                    que usa la clase Grammar que realiza el trabajo de leer 
//                    el fichero que especifica la gramatica
//                    cambiar la gramatica a forma normal de CHOMSKY
//                    e imprimir sus caracteristicas en un fichero de salida
// Referencias: 
//                    Enunciado de la pr�ctica:
//                    https://campusvirtual.ull.es/1920/pluginfile.php/147981/mod_assign/introattachment/0/CYA_1920_Practica_8.pdf?forcedownload=1
#include <iostream>
#include <string.h>
#include "grammar.cpp"
using namespace std;

int main( int argc, char** argv) {
  if( argc >= 2){  
    int help = strcmp( "--help", argv[1]);
    if( help == 0){
      cout << "El programa G2CNF necesita dos argumentos, dos nombres de ficheros" << '\n'
	<< "El primero debe contener la especificacion de una gramatica" << '\n' 
	<< "Y el segundo debe ser el fichero de salida donde se quiere imprimir" << '\n'
	<< "las caracteristicas del CNF" << '\n';
      return 0;
    }
  }
  if( argc == 3){
    Grammar gramatica( argv[1]);
    gramatica.ChomskyForm();
    gramatica.ImprimirGrammar( argv[2]);
  }
  else{
  cout << "Modo de empleo: ./G2CNF input.gra output.gra" << '\n'
    << "Pruebe ./G2CNF --help para mas informacion." << '\n' ;
  }
  return 0;
}
