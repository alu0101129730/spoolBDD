// Universidad de La Laguna
// Escuela Superior de Ingenier�a y Tecnolog�a
// Grado en Ingenier�a Inform�tica
// Asignatura: Computabilidad y Algoritmia (CyA)
// Curso: 2 
// Pr�ctica 9 CyA -  Gramaticas Regulares y Automatas Finitos
// Autor: Jose Yuyari Milian Martinelli
// Correo: alu0101129730@ull.es
// Fecha: 17/11/2019
// Archivo grammar.cpp: Aqui se desarrollan los metodos de la clase
//	      Grammar.
// Referencias: 
//                    Enunciado de la pr�ctica:
//                    https://campusvirtual.ull.es/1920/pluginfile.php/147981/mod_assign/introattachment/0/CYA_1920_Practica_8.pdf?forcedownload=1

#include "grammar.h"
using namespace std;

void Grammar::SetGrammar( string fichero){
  /*funcion que lee los atributos de la gramatica del fichero
   * cuyo nombre recibe como argumento */

  //Variables utilizadas temporalmente 
  int longitud_alfabeto, numero_no_terminales, numero_producciones;
  string comentario;

  ifstream stream_entrada_aux( fichero.c_str());
  string string_fichero;

  ofstream salida_temporal("temp.txt");
  //Bucle para quitar comentarios
  while( !stream_entrada_aux.eof()) { 
    string str_aux;
    getline( stream_entrada_aux, str_aux);
    if( str_aux[0] != '/' && str_aux[1] != '/'){
      salida_temporal << str_aux;
      if( !stream_entrada_aux.eof())
       salida_temporal << '\n';
    }
  }

  salida_temporal.close();
  ifstream stream_entrada( "temp.txt");
  //Funcion que lee el alfabeto
  stream_entrada >> longitud_alfabeto;
  cout <<longitud_alfabeto<<endl;
  for( int i = 0; i < (longitud_alfabeto); i++) {
    char simbolo;
    stream_entrada>>simbolo;
    cout<<"ESto es simbolo del alfabeto: "<<simbolo<<endl;
    if( simbolo != '~')
      alphabet.insert( simbolo);
  }
  //Funcion que lee los simbolos no terminales
  string str;
  stream_entrada >> str;
  numero_no_terminales = atoi(str.c_str());
  for( int i = 0; i < numero_no_terminales; i++) {
    string str_estado;
    stream_entrada >> str_estado;
    cout<<str_estado<<endl;
    non_terminal.insert(str_estado);
  }
  //Lee el no terminal inicial
  stream_entrada >> start;
  
  //Lee los estados de aceptacion
  stream_entrada >> numero_producciones;
  for( int i = 0; i < numero_producciones; i++) {
      string str_aux;
      vector<string> produccion;
      stream_entrada >> str_aux;
      produccion.push_back( str_aux);
      stream_entrada >> str_aux >> str_aux;
      produccion.push_back( str_aux);
      productions.insert( produccion);
  }
}
void Grammar::ChomskyForm(){
  /* funcion que convierte la gramatica a forma normal de Chomsky*/
  set<vector<string> > nuevo_set_producciones;
  int numero_no_terminales_nuevos = 0;
  for( set<vector<string> >::iterator it = productions.begin(); it != productions.end(); ++it) {
    try {
      if( (*it)[1] == "~")
        throw("Problema con cadena vacia en la produccion: \n" );
    } catch (const char* msg) {
        cout<< msg
             << (*it)[0] << " -> "
             << (*it)[1] << '\n';
	exit( 1);
    }
    vector<string> nueva_produccion;
    string destino_aux;
    nueva_produccion.push_back( (*it)[0]);
    if( (*it)[1].size() >= 2){
      for( int i = 0; i < (*it)[1].size(); i++){
	set<char>::iterator en_alfabeto = alphabet.find( (*it)[1][i]);
	if( en_alfabeto != alphabet.end()){
	  vector<string> nueva_prod;
	  ostringstream numero;
	  numero << numero_no_terminales_nuevos;
	  string num ="C_"; 
	  num += (*it)[1][i];
	  cout << "noterminakl: " <<num<<endl;
	  non_terminal.insert(num);
	  nueva_prod.push_back( num);
	  string simbolo = "";
	  simbolo += (*it)[1][i];
	  nueva_prod.push_back( simbolo);
	  nuevo_set_producciones.insert( nueva_prod);
	  //cambiar produccion actual
	  for( int j = 0; j < num.size(); j++)
	    destino_aux.push_back( num[j]);
	}
	else
		  destino_aux.push_back((*it)[1][i]);
      }
	  nueva_produccion.push_back( destino_aux);
	  nuevo_set_producciones.insert( nueva_produccion);
  }
  else
    nuevo_set_producciones.insert( *it);
  }
  productions = nuevo_set_producciones;
  nuevo_set_producciones.clear();
  for( set<vector<string> >::iterator it = productions.begin(); it != productions.end(); ++it) {
      string aux;
      vector<string> parte_der;
      for( int i = 0; i < (*it)[1].size(); i++){
        aux.push_back( (*it)[1][i]);
        set<string>::iterator no_ter = non_terminal.find( aux);
        if( no_ter != non_terminal.end()) {
          parte_der.push_back( aux);
          aux.clear();
        }
      }

    if( parte_der.size() >= 3) {
      string parte_izq = (*it)[0];
	cout<<"GUGU"<<endl;
	for( int i = 0; i < parte_der.size() - 2; i++){
	  vector<string> nueva_produccion;
	  nueva_produccion.push_back( parte_izq);
	  string ter_aux = parte_der[i];
	  ostringstream numero;
	  numero << numero_no_terminales_nuevos;
	  string num = "D_";
	  num += numero.str(); 
	  non_terminal.insert( num);
	  non_terminal.insert( num);
	  numero_no_terminales_nuevos++;
	  parte_izq = num;
	  nueva_produccion.push_back( ter_aux + num);
	  nuevo_set_producciones.insert( nueva_produccion);
	}
	cout<<"hola"<<endl;
	vector<string> nueva_produccion;
	ostringstream numero;
	numero << numero_no_terminales_nuevos - 1;
	string num = "D_" + numero.str(); 
	nueva_produccion.push_back( num);
	nueva_produccion.push_back( parte_der[ parte_der.size() - 2] + parte_der[ parte_der.size() - 1]);
	nuevo_set_producciones.insert( nueva_produccion);
      }
    else
      nuevo_set_producciones.insert( *it);
      cout<<"Y AQUI TAMPOCO" <<endl;
    }
  productions = nuevo_set_producciones;
  
} 
void Grammar::ImprimirGrammar( string salida_fichero){
  ofstream salida_stream( salida_fichero);
  //ALFABETO
  salida_stream << alphabet.size();
  for( set<char>::iterator it = alphabet.begin(); it != alphabet.end(); ++it)
    salida_stream << '\n' << *it;
  // NO TERMINALES
  salida_stream << '\n' << non_terminal.size();
  for( set<string>::iterator it = non_terminal.begin(); it != non_terminal.end(); ++it)
    salida_stream << '\n' << *it;
    salida_stream << '\n' << /*Inicial*/ start;
     //PRODUCCIONES
  salida_stream << '\n' << productions.size();
  for( set<vector<string> >::iterator it = productions.begin(); it != productions.end(); ++it)
    salida_stream << '\n' << (*it)[0] << " -> "  << (*it)[1];
}
/*
NFA Grammar::CreateNFA(){
  vector<string> nfa_states;
  vector<string> nfa_aceptaciones;
  vector<vector<string> > nfa_transitions;
  for( set<string>::iterator it = non_terminal.begin(); it != non_terminal.end(); ++it)
    nfa_states.push_back( *it);
  nfa_states.push_back( "F");
  nfa_aceptaciones.push_back( "F");
  //er
  SetNFAStatesTransitions( nfa_states, nfa_transitions);
  NFA new_Nfa( this->alphabet, nfa_states, this->start, nfa_aceptaciones, nfa_transitions);
  return new_Nfa;
}
*/
void Grammar::SetNFAStatesTransitions( vector<string> &states, vector<vector<string> > &transitions){
  bool theres_terminal;
  for( set< vector<string> >::iterator it = productions.begin(); it != productions.end(); ++it){
  string terminal = "";
    //El siguiente bucle determina si hay un terminal en la produccion actual
    for( int i = (*it)[1].length() - 1; i >= 0; i--){
      string aux;
      for(int j = i; j < (*it)[1].length(); j++)
	aux.push_back( (*it)[1][j]);
      set<string>::iterator ter = find( non_terminal.begin(), non_terminal.end(), aux);
      if( ter != non_terminal.end()){
	theres_terminal = true;
	for(int k = 0; k < aux.length(); k++)
	  terminal.push_back( aux[k]);
	break;
      }
      theres_terminal = false;
    }
    vector<string> new_states;
    new_states.push_back( (*it)[0]); //termino iniicial de la produccion

    for( int i = 0; i < (*it)[1].size() - terminal.length() - 1; i++){
      string new_state = "N_";
      char c = '0' + i;
      new_state += c;
      new_states.push_back( new_state);
    }
    string symbol;
    if ( !theres_terminal)
      symbol = "F";
    else
      symbol = terminal;
    new_states.push_back( symbol); 
    for( int i = 0; i < (*it)[1].size()  - terminal.length(); i++){
      vector< string> transicion;
      transicion.push_back( new_states[i]);
      cout<< '\n' <<"Simbolo transicion" << (*it)[1][i]<<endl;
      fflush( stdout);
      char c =(*it)[1][i];
      string aux= "";
      aux += c;
      transicion.push_back( aux);
      transicion.push_back( new_states[i+1]);
      transitions.push_back( transicion);
    }

    for( int i = 1; i < new_states.size(); i++) {
      vector<string>::iterator iterador = find( states.begin(), states.end(), new_states[i]);
      if( iterador == states.end())
        states.push_back( new_states[i]);
    }
    for( int i = 0; i < transitions.size(); i++) {
	cout << '\n' << "Transicion numero " << i << ": " << transitions[i][0] << " " << transitions[i][1] << " " << transitions[i][2] ;
    }
}
}

